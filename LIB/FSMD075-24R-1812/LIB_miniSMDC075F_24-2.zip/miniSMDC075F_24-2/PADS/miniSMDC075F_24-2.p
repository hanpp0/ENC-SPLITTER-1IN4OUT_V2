*PADS-LIBRARY-PART-TYPES-V9*

miniSMDC075F_24-2 MINISMDC050F2 I ANA 6 1 0 0 0
TIMESTAMP 2026.02.12.06.52.39
"Mouser Part Number" 650-MINISMDC075F/24
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Littelfuse/MINISMDC075F-24-2?qs=F6FIpiMdEVbDbC%2FX4s7sIg%3D%3D
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" miniSMDC075F/24-2
"Description" LITTELFUSE - MINISMDC075F/24-2 - FUSE, PTC RESET, 24V, 750mA, 1812
"Datasheet Link" https://componentsearchengine.com/Datasheets/2/MINISMDC050F-2.pdf
GATE 1 2 0
miniSMDC075F_24-2
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
610233/130691/2.50/2/4/Resettable Fuse
