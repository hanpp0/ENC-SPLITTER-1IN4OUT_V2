*PADS-LIBRARY-PART-TYPES-V9*

1812L075_24DR 1812L010DR I ANA 7 1 0 0 0
TIMESTAMP 2026.02.12.06.50.59
"Mouser Part Number" 576-1812L075/24DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Littelfuse/1812L075-24DR?qs=PWhpLWeW8wcogHUDToVN2w%3D%3D
"Manufacturer_Name" LITTELFUSE
"Manufacturer_Part_Number" 1812L075/24DR
"Description" PTC 24V POLYFUSE SURF MOUNT 1812 .750A
"Datasheet Link" http://www.littelfuse.com/~/media/electronics/datasheets/resettable_ptcs/littelfuse_ptc_1812l_datasheet.pdf.pdf
"Geometry.Height" 1.25mm
GATE 1 2 0
1812L075_24DR
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
652004/130691/2.50/2/4/Resettable Fuse
