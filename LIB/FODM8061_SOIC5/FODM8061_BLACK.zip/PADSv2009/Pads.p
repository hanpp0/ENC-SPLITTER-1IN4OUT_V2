*PADS-LIBRARY-PART-TYPES-V9*

FODM8061 MFP5_100AM_OSI:MFP5_100AM_OSI_M:MFP5_100AM_OSI_L I TRX 5 1 0 0
"Type" Optoisolators
"Copyright" Copyright (C) 2026 Ultra Librarian. All rights reserved.
"Manufacturer_Name" onsemi
"Manufacturer_Part_Number" FODM8061
"Part Number"
GATE 1 5 0
MFP5_100AM
1 0 U 1
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
